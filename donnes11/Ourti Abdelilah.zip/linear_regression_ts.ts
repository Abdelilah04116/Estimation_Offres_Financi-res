// Interface pour représenter un point cartésien
interface Point {
    x: number;
    y: number;
}

// Interface pour les résultats de la régression
interface RegressionResult {
    slope: number;        // coefficient directeur (a)
    intercept: number;    // ordonnée à l'origine (b)
    rSquared: number;     // coefficient de détermination R²
    equation: string;     // équation sous forme textuelle
}

class LinearRegression {
    private points: Point[];

    constructor(points: Point[]) {
        if (points.length < 2) {
            throw new Error("Au moins 2 points sont nécessaires pour la régression");
        }
        this.points = points;
    }

    // Calcule la régression linéaire y = ax + b
    public calculateRegression(): RegressionResult {
        const n = this.points.length;
        
        // Calcul des sommes nécessaires
        let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        
        for (const point of this.points) {
            sumX += point.x;
            sumY += point.y;
            sumXY += point.x * point.y;
            sumX2 += point.x * point.x;
        }

        // Calcul du coefficient directeur (slope)
        const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        
        // Calcul de l'ordonnée à l'origine (intercept)
        const intercept = (sumY - slope * sumX) / n;

        // Calcul du coefficient de détermination R²
        const rSquared = this.calculateRSquared(slope, intercept);

        // Formatage de l'équation
        const equation = this.formatEquation(slope, intercept);

        return {
            slope: Math.round(slope * 1000) / 1000,
            intercept: Math.round(intercept * 1000) / 1000,
            rSquared: Math.round(rSquared * 1000) / 1000,
            equation
        };
    }

    // Calcule le coefficient de détermination R²
    private calculateRSquared(slope: number, intercept: number): number {
        const meanY = this.points.reduce((sum, p) => sum + p.y, 0) / this.points.length;
        
        let totalSumSquares = 0;  // TSS
        let residualSumSquares = 0;  // RSS
        
        for (const point of this.points) {
            const predictedY = slope * point.x + intercept;
            totalSumSquares += Math.pow(point.y - meanY, 2);
            residualSumSquares += Math.pow(point.y - predictedY, 2);
        }
        
        return 1 - (residualSumSquares / totalSumSquares);
    }

    // Formate l'équation sous forme lisible
    private formatEquation(slope: number, intercept: number): string {
        const a = Math.round(slope * 1000) / 1000;
        const b = Math.round(intercept * 1000) / 1000;
        
        if (b >= 0) {
            return `y = ${a}x + ${b}`;
        } else {
            return `y = ${a}x - ${Math.abs(b)}`;
        }
    }

    // Prédit une valeur y pour un x donné
    public predict(x: number, result: RegressionResult): number {
        return result.slope * x + result.intercept;
    }

    // Affiche les points de données
    public displayPoints(): void {
        console.log("📊 Jeu de données (20 points):");
        console.log("┌─────────┬─────────┐");
        console.log("│    X    │    Y    │");
        console.log("├─────────┼─────────┤");
        
        this.points.forEach((point, index) => {
            console.log(`│ ${point.x.toString().padStart(7)} │ ${point.y.toString().padStart(7)} │`);
        });
        console.log("└─────────┴─────────┘");
    }

    // Affiche les résultats de la régression
    public displayResults(result: RegressionResult): void {
        console.log("\n🔍 Résultats de la régression linéaire:");
        console.log("═══════════════════════════════════════");
        console.log(`📈 Équation: ${result.equation}`);
        console.log(`📊 Coefficient directeur (a): ${result.slope}`);
        console.log(`📍 Ordonnée à l'origine (b): ${result.intercept}`);
        console.log(`🎯 Coefficient R² (qualité): ${result.rSquared}`);
        console.log(`💡 Qualité: ${this.interpretRSquared(result.rSquared)}`);
    }

    // Interprète la qualité du R²
    private interpretRSquared(rSquared: number): string {
        if (rSquared >= 0.9) return "Excellente (≥90%)";
        if (rSquared >= 0.7) return "Bonne (70-89%)";
        if (rSquared >= 0.5) return "Modérée (50-69%)";
        return "Faible (<50%)";
    }
}

// Génération d'un jeu de données de 20 points avec une tendance linéaire + bruit
function generateDataset(): Point[] {
    const points: Point[] = [];
    const trueSlope = 2.5;  // vraie pente
    const trueIntercept = 10;  // vraie ordonnée à l'origine
    
    // Génération de 20 points avec du bruit gaussien
    for (let i = 1; i <= 20; i++) {
        const x = i;
        const noise = (Math.random() - 0.5) * 8; // bruit aléatoire
        const y = trueSlope * x + trueIntercept + noise;
        
        points.push({
            x: Math.round(x * 10) / 10,
            y: Math.round(y * 10) / 10
        });
    }
    
    return points;
}

// Programme principal
function main(): void {
    console.log("🚀 SIMULATION DE RÉGRESSION LINÉAIRE");
    console.log("=====================================\n");

    try {
        // Génération du jeu de données
        const dataset = generateDataset();
        
        // Création de l'instance de régression
        const regression = new LinearRegression(dataset);
        
        // Affichage des données
        regression.displayPoints();
        
        // Calcul de la régression
        const result = regression.calculateRegression();
        
        // Affichage des résultats
        regression.displayResults(result);
        
        // Exemple de prédiction
        console.log("\n🔮 Exemple de prédiction:");
        const xTest = 25;
        const prediction = regression.predict(xTest, result);
        console.log(`Pour x = ${xTest}, y prédit = ${Math.round(prediction * 100) / 100}`);
        
    } catch (error) {
        console.error("❌ Erreur:", error);
    }
}

// Exécution du programme
main();